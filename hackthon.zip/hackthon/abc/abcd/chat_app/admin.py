from django.contrib import admin

# Register y1our models here.
from .models import chat
admin.site.register(chat)